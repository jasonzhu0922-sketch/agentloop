---
name: hr-report-analysis
description: 基于人事法人汇总报表回答员工人数、员工画像、人员结构与分布问题，分析性别、学历、职称、技能等级、岗位类型、青年员工与党员占比，以及组织比较和月度变化。负责明确口径、选择分析方法、形成数值结论和报告内容，委派 hr-report-data 读取原始数据；纯原始记录、组织匹配、月份或指标目录读取使用 hr-report-data。
agentloop:
  roles:
    - primary_builder
  artifactKinds:
    - none
  sourceKinds:
    - database
  qaKinds:
    - content
  executionProfiles:
    - local_script
  semanticTags:
    - hr-report-analysis
    - workforce-analysis
    - organization-comparison
    - employee-profile
    - employee-situation
    - human-resources-analysis
  intentExamples:
    - 某公司现在有多少员工，人员是怎么构成的
    - 分析某公司的员工画像，说明各维度人数、分布和占比
    - 查询某公司男女人数，分析学历、职称、技能等级和岗位结构
    - 计算某公司35岁以下员工和党员占在岗人数的比例
    - 对比某公司总部和全公司的人员结构及近一年变化
    - 根据人事汇总数据形成员工情况报告或仪表盘的分析内容
  requiredSkillNames:
    - hr-report-data
---

# 人事报表分析

本 Skill 是法人汇总人事指标数值结论的业务所有者。它确定月份、指标、组织范围和比较方法；`hr-report-data` 只负责组织精确匹配和原始行读取；本包的分析器只从持久化原始回执计算可复核事实。

## 使用边界

用户需要人数答案、员工画像、结构分布、占比、比较、变化或人事分析报告时，由本 Skill 主导，先确定回答方法，再委派取数。用户只要原始行、组织匹配、可用月份或指标定义时，使用 `hr-report-data`。

对话回答和文件报告使用同一套业务口径。需要生成文件时，将已核验的分析事实交给相应格式的制作能力；本 Skill 继续负责数值与结论，不把原始取数结果当成最终报告。

## 工作方式

1. 先明确问题需要的最小指标。分布问题应取得对应维度的完整子项；青年或党员占比还应同时取得同组织同月份的 `在岗员工人数`。
2. 加载并委派 `hr-report-data`。未指定月份时调用 `latest-period`，使用数据源实际最新月份。点名公司时将用户原始的组织表述和范围限定交给 `resolve-organizations`，原样使用其 selection，不自行增加总部限定或改写组织代码。
3. 调用 `query-report` 获取原始行，精确指标名称以子 Skill 的目录为准。不提交 SQL，不猜测组织代码，也不把总部和全公司人数相加。
4. 将工具返回的完整取数回执文件路径传给 `analyze-report --input-file`。通过 `computer_run_command` 取数时，该路径来自 `stdoutRef.path`，不是预览文本。只有分析器的 `derived_aggregation` 回执或等价、哈希绑定的可复核计算才能支撑占比、变化和排名结论。
5. 根据实际覆盖交付：单月单指标报告事实；完整分类集合可报告结构占比；多月同组织同指标可报告首末变化；组织排名必须保持 `full_company` 和 `headquarters` 两种口径分开。

跨步骤接收取数结果时，先读取正式依赖 Result，再使用其中保留的原始回执文件引用。概况和行数不代替原始输入；缺少可读取引用时补齐这项交接，不把“已取得原始数据”当成分析完成。

## 口径约束

- 全公司四位代码包含下属单位，总部 `XXXX00` 只含总部，二者重叠。
- 没有互斥组织范围证据时，不计算跨组织总人数。
- 分类占比只在同组织、同月份、同一完整维度内计算。
- 青年率和党员率只在同组织、同月份存在对应子集指标与在岗员工人数，且分母大于零时计算。
- 月度变化不等于人员流入流出，汇总表不能解释个人变化原因。
- 本数据集不支持群众/团员、民族、细分年龄段、工龄、绩效、离职、薪资或个人级画像。

## 交付

使用简洁 Markdown 说明结论、月份、组织口径、实际指标、关键数值和限制。区分原始人数、确定性计算和业务解释；不要展示接口凭据、SQL 原文、内部路径或回执 ID。

按用户实际请求交付人数、所需维度的分布或计算结果及相应解释。派生计算未完成时如实说明具体缺口；仅有取数完成声明、记录数或方法介绍，不构成已完成的画像分析。

需要选择分析方法或解释边界时读取 [分析方法](references/analysis-methodology.md)。字段与组织语义由 `hr-report-data` 的 [数据语义](../hr-report-data/references/data-semantics.md) 负责。

