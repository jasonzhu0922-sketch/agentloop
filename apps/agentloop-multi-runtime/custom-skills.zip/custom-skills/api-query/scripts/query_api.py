#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
query_api.py - 数智域通用 SQL API 客户端

调用宝武数据中台通用 SQL API：
    POST https://eplat.baocloud.cn/service/D_A_BSTABD00_SHUTU_AGENT
    Body: {"sql": "...", "clientId": "...", "clientSecret": "...", "offset": "0", "limit": "1000"}

返回结构：
    __sys__.status               1=成功, -1=失败
    __sys__.msg                  提示信息
    __blocks__.result.meta.columns   [{name, descName, type}]   (descName 恒为空)
    __blocks__.result.rows           [[...], ...]  (二维数组)
    resultCount                  行数(字符串)

注意：
    - API 会自动追加 "fetch first 1000 rows only"，SQL 里不要再写 fetch/limit
    - 分页用 body 的 offset(从0开始)/limit 参数
    - 底层是 DB2，查字段中文注释用 SYSCAT.COLUMNS.REMARKS

用法：
    python3 query_api.py "select ... from ..."
    python3 query_api.py --columns BSTAMSCW00 TAFTBC2
"""

import json
import os
import sys
import subprocess
from pathlib import Path
from urllib import parse

DEFAULT_API_URL = "https://eplat.baocloud.cn/service/D_A_BSTABD00_SHUTU_AGENT"
CONFIG_KEYS = {"API_QUERY_API_URL", "EPLAT_CLIENT_ID", "EPLAT_CLIENT_SECRET"}
CURL_STATUS_MARKER = b"\n__agentloop_api_query_http_status__:"
TIMEOUT = 120
DEFAULT_LIMIT = 1000


class ApiError(Exception):
    """API 调用失败"""

    def __init__(self, msg, api_sql=None):
        self.msg = msg
        self.api_sql = api_sql
        super().__init__(msg)


def _parse_dotenv(path):
    values = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key not in CONFIG_KEYS:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        values[key] = value
    return values


def _read_config():
    environment_file = os.environ.get("API_QUERY_ENV_FILE", "").strip()
    if not environment_file:
        raise ApiError("api-query deployment configuration is unavailable")
    try:
        values = _parse_dotenv(Path(environment_file))
    except OSError:
        raise ApiError("api-query deployment configuration is unavailable") from None
    api_url = values.get("API_QUERY_API_URL", DEFAULT_API_URL).strip()
    client_id = values.get("EPLAT_CLIENT_ID", "").strip()
    client_secret = values.get("EPLAT_CLIENT_SECRET", "").strip()
    parsed = parse.urlsplit(api_url)
    if (
        parsed.scheme != "https"
        or not parsed.netloc
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ApiError("api-query API URL must be an HTTPS URL without credentials, query, or fragment")
    if not client_id or not client_secret:
        raise ApiError("api-query deployment configuration is incomplete")
    return api_url.rstrip("/"), client_id, client_secret


def query(sql, offset=0, limit=DEFAULT_LIMIT, timeout=TIMEOUT):
    """执行 SQL，返回 {"columns": [...], "rows": [[...]], "count": int, "api_sql": str}"""
    api_url, client_id, client_secret = _read_config()
    body = {
        "sql": sql,
        "clientId": client_id,
        "clientSecret": client_secret,
        "offset": str(offset),
        "limit": str(limit),
    }
    command = [
        "curl",
        "--silent",
        "--show-error",
        "--request",
        "POST",
        "--connect-timeout",
        "10",
        "--max-time",
        str(max(1, int(timeout))),
        "--header",
        "content-type: application/json",
        "--header",
        "accept: application/json",
        "--data-binary",
        "@-",
        "--write-out",
        "\n__agentloop_api_query_http_status__:%{http_code}",
        api_url,
    ]
    try:
        completed = subprocess.run(
            command,
            input=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=max(5, int(timeout) + 5),
            check=False,
        )
    except FileNotFoundError:
        raise ApiError("api-query HTTP transport is unavailable (curl is not installed)") from None
    except subprocess.TimeoutExpired:
        raise ApiError("api-query request timed out") from None

    status_position = completed.stdout.rfind(CURL_STATUS_MARKER)
    if status_position < 0:
        if completed.returncode == 28:
            raise ApiError("api-query request timed out")
        if completed.returncode == 35:
            raise ApiError("api-query TLS handshake failed")
        if completed.returncode == 60:
            raise ApiError("api-query TLS certificate verification failed")
        raise ApiError(f"api-query request failed (transport code {completed.returncode})")
    raw = completed.stdout[:status_position]
    status_text = completed.stdout[status_position + len(CURL_STATUS_MARKER):].strip()
    try:
        status_code = int(status_text)
    except ValueError:
        raise ApiError("api-query returned an invalid HTTP status") from None
    # curl writes HTTP 000 when no HTTP response was received. Classify the
    # transport failure first so DNS/TLS/connectivity errors are not reported
    # as an invented HTTP status or mistaken for credential rejection.
    if completed.returncode != 0:
        if completed.returncode == 28:
            raise ApiError("api-query request timed out")
        if completed.returncode == 35:
            raise ApiError("api-query TLS handshake failed")
        if completed.returncode == 60:
            raise ApiError("api-query TLS certificate verification failed")
        raise ApiError(f"api-query request failed (transport code {completed.returncode})")
    if status_code < 200 or status_code >= 300:
        raise ApiError(f"api-query returned HTTP {status_code}")
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ApiError("api-query returned invalid JSON") from None

    status = data.get("__sys__", {}).get("status")
    msg = data.get("__sys__", {}).get("msg", "")
    if status != 1:
        # 结果集为空不算错误，返回空
        if "结果集为空" in msg:
            result = data.get("__blocks__", {}).get("result", {})
            columns = [c["name"] for c in result.get("meta", {}).get("columns", [])]
            return {"columns": columns, "rows": [], "count": 0, "api_sql": data.get("apiSql")}
        detail = msg or "no business error message"
        raise ApiError(f"api-query rejected the SQL request (status={status}): {detail}", data.get("apiSql"))

    result = data.get("__blocks__", {}).get("result", {})
    columns = [c["name"] for c in result.get("meta", {}).get("columns", [])]
    rows = result.get("rows", [])
    try:
        count = int(data.get("resultCount", len(rows)))
    except (TypeError, ValueError):
        count = len(rows)
    return {"columns": columns, "rows": rows, "count": count, "api_sql": data.get("apiSql")}


def query_dicts(sql, offset=0, limit=DEFAULT_LIMIT, timeout=TIMEOUT):
    """执行 SQL，返回 [{col: val, ...}, ...] 列表"""
    res = query(sql, offset=offset, limit=limit, timeout=timeout)
    cols = res["columns"]
    return [dict(zip(cols, row)) for row in res["rows"]]


def query_columns_remarks(schema, table):
    """查询某表所有字段的中文注释，返回 {COLNAME: 中文注释}（注释为空则 value 为 ''）"""
    sql = (
        f"select COLNAME, REMARKS from SYSCAT.COLUMNS "
        f"where TABNAME = '{table}' and TABSCHEMA = '{schema}'"
    )
    rows = query_dicts(sql)
    return {r["COLNAME"]: (r["REMARKS"] or "").strip() for r in rows}


def find_schema(table):
    """裸表名反查 schema：同名多 schema 时返回列表，供调用方判断歧义"""
    sql = f"select distinct TABSCHEMA from SYSCAT.TABLES where TABNAME = '{table}'"
    rows = query_dicts(sql)
    return [r["TABSCHEMA"].strip() for r in rows]


def _main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--columns":
        schema, table = sys.argv[2], sys.argv[3]
        remarks = query_columns_remarks(schema, table)
        for col, remark in sorted(remarks.items()):
            print(f"{col}\t{remark}")
        return

    sql = " ".join(sys.argv[1:])
    if not sql.strip():
        print(__doc__)
        return
    try:
        res = query(sql)
    except ApiError as e:
        print(f"ERROR: {e.msg}", file=sys.stderr)
        if e.api_sql:
            print(f"apiSql: {e.api_sql}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    _main()
