---
name: steel-market-analysis
description: 将可核验的钢材数据库时序转为趋势、区间、比较或风险分析。用于需要钢材价格或指标数值结论的任务；它委派 mysql-steel-data 取得原始数据。纯目录、候选或原始时序读取使用 mysql-steel-data。
agentloop:
  roles:
    - primary_builder
  artifactKinds:
    - none
  sourceKinds:
    - database
  qaKinds:
    - content
  executionProfiles:
    - local_script
  semanticTags:
    - steel-market
    - commodity-price
    - time-series-analysis
  intentExamples:
    - 查询指定日期、地区、生产企业、牌号和规格对应的钢材价格或指标数值
    - 比较钢材指标在一段时间内的走势、区间、涨跌或区域差异
  requiredSkillNames:
    - mysql-steel-data
---

# 钢材市场分析

本 Skill 是钢材数值结论的业务所有者。它决定研究问题、最小证据、可比性和交付结论；`mysql-steel-data` 只负责受控地取得原始事实，Python 只负责从已取得的原始事实计算可复核的数值画像。

## 何时使用

用户需要走势、涨跌、区间、峰谷、比较、区域差异或风险判断时，先加载本 Skill。不要让数据源 Skill 直接交付这类结论。

用户只要目录、候选、字段语义或原始时序，且明确不要数值解释时，改用 `mysql-steel-data`，不要加载本 Skill。

## 分析职责

1. 先确定要回答的问题、适合的方法和最小原始证据。不要因数据库可返回什么就改变用户的研究对象，也不要一次取无关历史或指标。
2. 加载并委派 `mysql-steel-data`。由它完成目录映射、唯一指标定位和原始行读取；不要猜表、列、关联键，也不要提交 SQL。
3. 取数方式由方法决定：单一、日期明确且可唯一确认的序列可用 `resolve-and-locate-series`；多指标、候选歧义或需要比较时，先写入 Run 工作区的 `agentloop.steelMarketQueryPlan/v1`，再调用 `execute-query-plan`。计划只记录方法、用途、日期和受控选择器，不含 SQL 或物理字段。
4. 把下层完整回执的 `contentLocation.path` 交给 `analyze-series --input-file`。摘要、stdout、行数和手工复制的数据不能替代这个输入。若受控计算器不覆盖所需的中性变换，可使用 Runtime 的通用计算协议，并让输出精确回指哈希绑定的原始输入。
5. 根据实际数据形态选择结论：唯一日值可讨论首末变化；同日多值应讨论每日集合或区间边界，不擅自选代表价。资料不足时降级为仍被事实支持的描述，或清楚说明不能判断的边界。

## 证据与交接

原始数据库事实只能来自 `mysql-steel-data` 的 `evidenceReceipt`；数值结论只能建立在 `analyze-series` 或等价的可复核计算事实之上。下层取数完成时，只交接持久化原始回执、覆盖范围和限制，不把取数步骤伪装成最终市场分析。

没有完成派生计算时，可以交付“已取得/未取得哪些原始数据”，但不能交付走势、涨跌、峰谷或因果结论。工具成功、脚本日志和模型常识都不是数据库事实。

## 交付

用与问题匹配的简洁 Markdown：给出结论、指标与单位、实际覆盖、支撑结论的关键数值，以及数据限制。明确区分数据观察、业务解释假设和无法由当前数据推出的内容；不要把 Python 摘要或回执 ID 当作分析本身。

## 按需参考

- 多指标比较、可比性不明确、供需/成本/期现研究设计时，读取 [分析方法论](references/market-analysis-methodology.md)。
- 需要了解字段、表、关联或受控选择器时，加载 `mysql-steel-data` 后读取其 [数据语义](../mysql-steel-data/references/data-semantics.md)。
